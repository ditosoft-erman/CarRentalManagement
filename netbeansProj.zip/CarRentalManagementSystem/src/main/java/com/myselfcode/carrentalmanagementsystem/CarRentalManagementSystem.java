/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.myselfcode.carrentalmanagementsystem;
import Authentication.LoginForm;

/**
 * Princess Niezza M. Catalan
 * Ralph Jazer Arcaya
 * Joshua Langub
 * Christian Estaniel
 * 
 * 
 */


public class CarRentalManagementSystem {

   
    
    public static void main(String[] args) {
        LoginForm lf = new LoginForm();
        lf.setVisible(true);
    }
}
