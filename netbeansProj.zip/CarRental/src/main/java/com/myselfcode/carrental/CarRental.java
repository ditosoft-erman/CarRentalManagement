/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.myselfcode.carrental;
import Authentication.Login;
import system.CustomerRegistration;

/**
 *
 * @author Vanessa
 */


public class CarRental {

    public static void main(String[] args) {
        Login lf = new Login();
       lf.show();
       
      
    }
}
